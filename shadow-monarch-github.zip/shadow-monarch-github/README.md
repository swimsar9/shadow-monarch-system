# THE SYSTEM — Shadow Monarch Edition ⚔️

A static RPG quest tracker for med school, strength training, BJJ and an 11-week 15K running arc.

## Deploy

Upload **the contents of this folder** to your GitHub repository root (keep the `assets/` folder). Then open **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**.

This is a front-end only site. Daily quests, XP, and settings are stored in **your own browser**, not in the GitHub repository. They do not sync across devices. Export JSON backups in Settings regularly, and import them on another device if needed. Do not commit personal backup JSON files to the public repository.

Official quest tracking starts October 12, 2026. Historical achievements are badges and grant no retroactive XP.

## Run locally

Open `index.html` in a browser, or use a simple local web server. No npm installation or build process is required.
