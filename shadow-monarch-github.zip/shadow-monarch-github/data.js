window.SYSTEM_DATA = {
  "gym": [
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Warm-up",
      "exercise": "Stairmaster",
      "sets": "",
      "target": "5 min",
      "notes": "Speed 3–5"
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Warm-up",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": "Dynamic warm-up"
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Strength",
      "exercise": "Hip thrusts → KAS glute bridges + hold",
      "sets": "3",
      "target": "8–10",
      "notes": "Superset/sequence per your notes"
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Strength",
      "exercise": "B-stance RDLs",
      "sets": "3",
      "target": "8–10 each side",
      "notes": ""
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Strength",
      "exercise": "Bulgarian split squats",
      "sets": "2",
      "target": "10–12 each side",
      "notes": ""
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Strength",
      "exercise": "Calf extensions",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Strength",
      "exercise": "Cable kickbacks / side kickbacks",
      "sets": "2 / 2",
      "target": "12 each side",
      "notes": ""
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Cardio",
      "exercise": "Treadmill",
      "sets": "",
      "target": "30 min",
      "notes": "Incline 5, speed 3.0"
    },
    {
      "day": "Monday",
      "focus": "GLUTES",
      "phase": "Cooldown",
      "exercise": "Stretching / red light sauna",
      "sets": "",
      "target": "",
      "notes": "Sauna optional; hydration"
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Warm-up",
      "exercise": "Row machine",
      "sets": "",
      "target": "1000 m",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Warm-up",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Assisted pull-ups",
      "sets": "3",
      "target": "AMRAP",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Lat pulldowns",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Rows",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Face pulls",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Rear delt flys",
      "sets": "2",
      "target": "8–10 each side",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Bicep curls + hammer curls",
      "sets": "2",
      "target": "8–10",
      "notes": "Compound set"
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Strength",
      "exercise": "Back extensions",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Core",
      "exercise": "Core circuit",
      "sets": "",
      "target": "10 min",
      "notes": ""
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Cardio",
      "exercise": "Stairmaster",
      "sets": "",
      "target": "15–20 min",
      "notes": "Speed 5; may be replaced by planned run"
    },
    {
      "day": "Tuesday",
      "focus": "BACK + CORE",
      "phase": "Cooldown",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Warm-up",
      "exercise": "Stairmaster",
      "sets": "",
      "target": "5 min",
      "notes": "Speed 3–5"
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Warm-up",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Strength",
      "exercise": "Hamstring curls",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Strength",
      "exercise": "Quad extensions",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Strength",
      "exercise": "Leg press",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Strength",
      "exercise": "RDLs",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Strength",
      "exercise": "Hyperextensions",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Strength",
      "exercise": "Calf extensions",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Cardio",
      "exercise": "Treadmill",
      "sets": "",
      "target": "30 min",
      "notes": "Incline 3–5, speed 3.0"
    },
    {
      "day": "Wednesday",
      "focus": "GLUTES + QUADS",
      "phase": "Cooldown",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Warm-up",
      "exercise": "Row machine",
      "sets": "",
      "target": "1000 m",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Warm-up",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Strength",
      "exercise": "Bench press",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Strength",
      "exercise": "Tricep pushdowns",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Strength",
      "exercise": "Cable lateral raises",
      "sets": "3",
      "target": "8 each side",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Strength",
      "exercise": "Chest flys",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Strength",
      "exercise": "Shoulder press",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Strength",
      "exercise": "Pushups",
      "sets": "3",
      "target": "AMRAP",
      "notes": "Counts toward Saitama total"
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Core",
      "exercise": "Core circuit",
      "sets": "",
      "target": "10 min",
      "notes": ""
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Cardio",
      "exercise": "Stairmaster",
      "sets": "",
      "target": "15–20 min",
      "notes": "Speed 5; may be replaced by planned run"
    },
    {
      "day": "Thursday",
      "focus": "CHEST + CORE",
      "phase": "Cooldown",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Warm-up",
      "exercise": "Stairmaster",
      "sets": "",
      "target": "5 min",
      "notes": "Speed 3–5"
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Warm-up",
      "exercise": "Stretching",
      "sets": "",
      "target": "",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Strength",
      "exercise": "Hamstring curls",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Strength",
      "exercise": "Hip abductions / adductions",
      "sets": "3 / 2",
      "target": "AMRAP",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Strength",
      "exercise": "Hip thrusts → KAS glute bridges + hold",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Strength",
      "exercise": "RDLs",
      "sets": "3",
      "target": "8–10",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Strength",
      "exercise": "Goblet squats",
      "sets": "3",
      "target": "10–12",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Strength",
      "exercise": "Step-ups",
      "sets": "2",
      "target": "10–12 each side",
      "notes": ""
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Cardio",
      "exercise": "Treadmill",
      "sets": "",
      "target": "30 min",
      "notes": "Incline 3–5, speed 3.0"
    },
    {
      "day": "Friday",
      "focus": "GLUTES + HAMS",
      "phase": "Cooldown",
      "exercise": "Stretching / red light sauna",
      "sets": "",
      "target": "",
      "notes": "Reduce fatigue before Saturday long run if needed"
    }
  ],
  "runningPlan": [
    {
      "week": 13,
      "start": "Oct 12",
      "tue": "4K easy + 4 strides",
      "thu": "4K easy",
      "sat": "8K",
      "focus": "Ease into new med-school module"
    },
    {
      "week": 14,
      "start": "Oct 19",
      "tue": "5K incl. 3 × 4-min tempo",
      "thu": "4K easy",
      "sat": "9K",
      "focus": "Controlled tempo effort"
    },
    {
      "week": 15,
      "start": "Oct 26",
      "tue": "5K incl. 5 × 2-min intervals",
      "thu": "5K easy",
      "sat": "10K",
      "focus": "Brisk, not all-out"
    },
    {
      "week": 16,
      "start": "Nov 2",
      "tue": "4K easy",
      "thu": "4K easy",
      "sat": "8K",
      "focus": "RECOVERY WEEK"
    },
    {
      "week": 17,
      "start": "Nov 9",
      "tue": "6K incl. 2 × 8-min tempo",
      "thu": "5K easy",
      "sat": "11K",
      "focus": "Keep long run conversational"
    },
    {
      "week": 18,
      "start": "Nov 16",
      "tue": "6K incl. 4 × 3-min intervals",
      "thu": "5K easy",
      "sat": "12K",
      "focus": "Monitor fatigue after Friday legs"
    },
    {
      "week": 19,
      "start": "Nov 23",
      "tue": "4K easy + strides",
      "thu": "4K easy",
      "sat": "10K",
      "focus": "RECOVERY WEEK"
    },
    {
      "week": 20,
      "start": "Nov 30",
      "tue": "6K incl. 3 × 7-min tempo",
      "thu": "5K easy",
      "sat": "12K",
      "focus": "Sustain comfortable endurance"
    },
    {
      "week": 21,
      "start": "Dec 7",
      "tue": "6K incl. 5 × 3-min intervals",
      "thu": "5–6K easy",
      "sat": "13K",
      "focus": "Fuel and recover adequately"
    },
    {
      "week": 22,
      "start": "Dec 14",
      "tue": "5K incl. 12-min tempo",
      "thu": "4–5K easy",
      "sat": "14K",
      "focus": "Reduced Tuesday intensity"
    },
    {
      "week": 23,
      "start": "Dec 21",
      "tue": "4K easy + strides",
      "thu": "3K easy or rest",
      "sat": "15K goal",
      "focus": "Dec 26 · Only if recovered/ready"
    }
  ],
  "questRules": [
    {
      "attribute": "INT",
      "name": "Daily Anki",
      "xp": 20,
      "rule": "1 when completed"
    },
    {
      "attribute": "INT",
      "name": "Scheduled lectures",
      "xp": 25,
      "rule": "Only when target >0 and completed >= target"
    },
    {
      "attribute": "INT",
      "name": "Extra practice/review",
      "xp": 15,
      "rule": "1 when done"
    },
    {
      "attribute": "STR",
      "name": "Gym session",
      "xp": 30,
      "rule": "1 per scheduled gym day"
    },
    {
      "attribute": "END",
      "name": "Run Tue / Thu",
      "xp": 25,
      "rule": "1 per planned run"
    },
    {
      "attribute": "END",
      "name": "Saturday long run",
      "xp": 35,
      "rule": "1 per planned long run"
    },
    {
      "attribute": "AGI",
      "name": "Sunday BJJ",
      "xp": 30,
      "rule": "1 per session"
    },
    {
      "attribute": "STR",
      "name": "100 pushups",
      "xp": 10,
      "rule": "Proportional to reps/100, capped at 10"
    },
    {
      "attribute": "STR",
      "name": "100 sit-ups",
      "xp": 10,
      "rule": "Proportional to reps/100, capped at 10"
    },
    {
      "attribute": "END",
      "name": "100 burpees",
      "xp": 10,
      "rule": "Proportional to reps/100, capped at 10"
    },
    {
      "attribute": "END",
      "name": "10,000 steps",
      "xp": 15,
      "rule": "When reported steps >= target"
    },
    {
      "attribute": "AGI",
      "name": "Mobility",
      "xp": 10,
      "rule": "1 for 10–15 min"
    },
    {
      "attribute": "NUT",
      "name": "Nutrition plan",
      "xp": 15,
      "rule": "Follow agreed adequate fueling plan"
    },
    {
      "attribute": "NUT",
      "name": "Protein",
      "xp": 15,
      "rule": "At least 127 g"
    },
    {
      "attribute": "VIT",
      "name": "Sleep goal",
      "xp": 15,
      "rule": "Follow intended schedule and confirm"
    },
    {
      "attribute": "DIS",
      "name": "Daily planning",
      "xp": 10,
      "rule": "1 when done"
    },
    {
      "attribute": "STR",
      "name": "Strength PR",
      "xp": 10,
      "rule": "1 for new weight/reps milestone"
    },
    {
      "attribute": "INT",
      "name": "Friday quiz passed",
      "xp": 50,
      "rule": "1 when passed"
    },
    {
      "attribute": "INT",
      "name": "Module exam passed",
      "xp": 150,
      "rule": "1 when passed"
    },
    {
      "attribute": "INT",
      "name": "Problem-solving exam passed",
      "xp": 100,
      "rule": "1 when passed"
    }
  ]
};
